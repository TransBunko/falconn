#ifndef _FHT_H_
#define _FHT_H_

int FHTFloat(float *buffer, int len, int chunk);
int FHTDouble(double *buffer, int len, int chunk);

#include "fht_impl.h"

#endif
